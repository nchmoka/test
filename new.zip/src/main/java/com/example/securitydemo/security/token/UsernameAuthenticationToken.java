
package com.example.securitydemo.security.token;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;

public class UsernameAuthenticationToken extends AbstractAuthenticationToken {

    private final String username;

    public UsernameAuthenticationToken(String username, Collection<? extends GrantedAuthority> authorities) {
        super(authorities);
        this.username = username;
        super.setAuthenticated(true); // must use super, otherwise it will call our overridden, which forbids
    }

    public UsernameAuthenticationToken(String username) {
        super(null);
        this.username = username;
        super.setAuthenticated(false);
    }

    @Override
    public Object getCredentials() {
        return null; // No password flow
    }

    @Override
    public Object getPrincipal() {
        return username;
    }
}
