
package com.example.securitydemo.security.filter;

import com.example.securitydemo.security.token.UsernameAuthenticationToken;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@RequiredArgsConstructor
public class UsernameAuthFilter extends OncePerRequestFilter {

    private final AuthenticationManager authenticationManager;

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain) throws ServletException, IOException {

        if (!requiresAuth(request)) {
            filterChain.doFilter(request, response);
            return;
        }

        String username = request.getHeader("X-Username");
        if (username == null || username.isBlank()) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Missing X-Username header");
            return;
        }

        UsernameAuthenticationToken authRequest = new UsernameAuthenticationToken(username);
        try {
            var authResult = authenticationManager.authenticate(authRequest);
            SecurityContextHolder.getContext().setAuthentication(authResult);
        } catch (AuthenticationException ex) {
            SecurityContextHolder.clearContext();
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Authentication failed: " + ex.getMessage());
            return;
        }

        filterChain.doFilter(request, response);
    }

    /**
     * Determine whether the current request is considered protected
     * according to the specification:
     *  - Any URI containing /approve/   → protected (admin)
     *  - Any non‑GET request            → protected (manager)
     *  - GET requests not containing /approve/ → public
     */
    private boolean requiresAuth(HttpServletRequest request) {
        String uri = request.getRequestURI();
        String method = request.getMethod();
        // TODO: add check for /reject/
        if (uri.contains("/approve/")) {
            return true;
        }

        return !HttpMethod.GET.matches(method);
    }
}
