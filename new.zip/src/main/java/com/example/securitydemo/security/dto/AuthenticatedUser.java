
package com.example.securitydemo.security.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AuthenticatedUser {
    private String username;
    /**
     * Either 'admin' or 'manager'
     */
    private String role;
}
