package com.example.securitydemo.infrastructure.api;

import com.example.securitydemo.application.service.ValidateUserUseCase;
import com.example.securitydemo.security.dto.AuthenticatedUser;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service
@Profile("auto") // or @Profile({"load", "auto"})
@Slf4j
public class StubUserApiService implements ValidateUserUseCase {

    public AuthenticatedUser validate(String username) {
        log.info("[STUB] skipping external call for {}", username);
        return switch (username.toLowerCase()) {
            case "admin"   -> new AuthenticatedUser(username, "admin");
            case "manager" -> new AuthenticatedUser(username, "manager");
            default        -> null;
        };
    }
}