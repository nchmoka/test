package com.example.securitydemo.infrastructure.security;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import shared.CurrentUser;

@Component                // registered automatically
public class SecurityContextCurrentUser implements CurrentUser {

    @Override
    public String username() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return (auth == null || !auth.isAuthenticated()) ? null
                : auth.getName();
    }
}
