
package com.example.securitydemo.infrastructure.api;

import com.example.securitydemo.application.service.ValidateUserUseCase;
import com.example.securitydemo.security.dto.AuthenticatedUser;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

/**
 * Simulates the call to an external identity provider.
 * In production you would use WebClient / RestTemplate here.
 */
@Service
@Profile({"load", "prod"})  // or @Profile("load")
@Slf4j
public class ExternalUserApiService implements ValidateUserUseCase {

    @Override
    @Cacheable(
            cacheNames = "userRoles",
            key = "#username",
            unless = "#result == null"
    )    public AuthenticatedUser validate(String username) {
        log.info("Calling external API for username: {}", username);

        return switch (username.toLowerCase()) {
            case "admin" -> new AuthenticatedUser(username, "admin");
            case "manager" -> new AuthenticatedUser(username, "manager");
            default -> null;
        };
    }
}
