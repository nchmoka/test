
package com.example.securitydemo.application.service;

import com.example.securitydemo.security.dto.AuthenticatedUser;

public interface ValidateUserUseCase {

    /**
     * Fetch user role from external source.
     * @param username the unique username header
     * @return an {@link AuthenticatedUser} or {@code null} when user is unknown
     */
    AuthenticatedUser validate(String username);
}
