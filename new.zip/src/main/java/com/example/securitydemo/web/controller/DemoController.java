
package com.example.securitydemo.web.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import shared.CurrentUser;

import java.util.List;

/**
 * Sample controller exposing public, manager‑protected, and admin‑protected routes.
 * The security rules are mapped by {@code UsernameAuthFilter} and {@code SecurityConfig}.
 */
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class DemoController {

    private final CurrentUser currentUser;

    @GetMapping("/ping")
    public ResponseEntity<String> ping() {
        return ResponseEntity.ok("pong");
    }

    @GetMapping("/info")
    public ResponseEntity<String> info() {
        return ResponseEntity.ok("public information");
    }

    // ========= Manager / Admin endpoints (non‑GET) =========

    @PostMapping("/manage/data")
    public ResponseEntity<String> postData(@RequestBody String body) {
        return ResponseEntity.ok("manager handled: " + body);
    }

    @PutMapping("/manage/item/{id}")
    public ResponseEntity<String> updateItem(@PathVariable String id,
                                             @RequestBody String body) {
        return ResponseEntity.ok("updated " + id + " with " + body);
    }

    @DeleteMapping("/manage/item/{id}")
    public ResponseEntity<String> deleteItem(@PathVariable String id) {
        return ResponseEntity.ok("deleted " + id);
    }

    // ========= Admin‑only endpoints (contain /approve/) =========

    @GetMapping("/tasks/approve/{id}")
    public ResponseEntity<String> approve(@PathVariable String id) {
        return ResponseEntity.ok("approved " + id);
    }

    @PostMapping("/tasks/approve/bulk")
    public ResponseEntity<String> bulkApprove(@RequestBody List<String> ids) {
        return ResponseEntity.ok("bulk approved: " + ids);
    }
}
