package shared;

public interface CurrentUser {
    String username();
}
