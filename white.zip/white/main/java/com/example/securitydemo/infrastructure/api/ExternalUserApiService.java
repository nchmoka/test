package com.example.securitydemo.infrastructure.api;

import com.example.securitydemo.application.service.ValidateUserUseCase;
import com.example.securitydemo.security.dto.AuthenticatedUser;
import org.springframework.stereotype.Service;

@Service
public class ExternalUserApiService implements ValidateUserUseCase {

    @Override
    @Cacheable(cacheNames = "users", key = "#username", unless = "#result == null")

    public AuthenticatedUser validate(String username) {
        return switch (username.toLowerCase()) {
            case "admin" -> new AuthenticatedUser(username, "admin");
            case "manager" -> new AuthenticatedUser(username, "manager");
            default -> null;
        };
    }
}
