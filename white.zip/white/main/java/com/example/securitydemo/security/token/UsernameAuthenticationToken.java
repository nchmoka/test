package com.example.app.auth;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import java.util.Collection;

/** Carries ONLY the username – no password, no credentials of any kind */
public class UsernameAuthenticationToken extends AbstractAuthenticationToken {

    private final String principal;   // the username

    /** unauthenticated constructor */
    public UsernameAuthenticationToken(String principal) {
        super(null);
        this.principal = principal;
        setAuthenticated(false);
    }

    /** authenticated constructor */
    public UsernameAuthenticationToken(String principal,
                                       Collection<? extends GrantedAuthority> authorities) {
        super(authorities);
        this.principal = principal;
        setAuthenticated(true);
    }

    @Override public Object getCredentials() { return null; }      // nothing to expose
    @Override public Object getPrincipal()    { return principal; }
}
