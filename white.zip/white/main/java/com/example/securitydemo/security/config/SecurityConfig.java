package com.example.securitydemo.security.config;

import com.example.securitydemo.security.filter.UsernameAuthFilter;
import com.example.securitydemo.security.provider.UsernameAuthenticationProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@RequiredArgsConstructor
public class SecurityConfig {

    private final UsernameAuthenticationProvider usernameAuthenticationProvider;

    @Bean
    CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration cfg = new CorsConfiguration();
        cfg.setAllowedOrigins(List.of("http://localhost:3000"));
        cfg.setAllowedMethods(List.of("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"));
        cfg.setAllowedHeaders(List.of("Content-Type", "Authorization", "X-Username"));
        cfg.setAllowCredentials(true);
        cfg.setMaxAge(Duration.ofHours(1));

        UrlBasedCorsConfigurationSource src = new UrlBasedCorsConfigurationSource();
        src.registerCorsConfiguration("/**", cfg);
        return src;
    }

    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http,
                                            UsernameAuthFilter filter) throws Exception {

        http.cors(Customizer.withDefaults())
            .csrf(csrf -> csrf.disable())
            .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authenticationProvider(provider)
            .addFilterBefore(filter, org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter.class)
            .httpBasic(Customizer.withDefaults()).and()
            .formLogin(AbstractHttpConfigurer::disable)
            .authorizeHttpRequests(auth -> auth
                // allow pre‑flight
                .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()

                // ADMIN: any path containing "/approve/"
                .requestMatchers("/**/approve/**", "/approve/**").hasRole("ADMIN")

                // MANAGER (also ADMIN): every non‑GET
                .requestMatchers(HttpMethod.POST,   "/**").hasAnyRole("MANAGER", "ADMIN")
                .requestMatchers(HttpMethod.PUT,    "/**").hasAnyRole("MANAGER", "ADMIN")
                .requestMatchers(HttpMethod.PATCH,  "/**").hasAnyRole("MANAGER", "ADMIN")
                .requestMatchers(HttpMethod.DELETE, "/**").hasAnyRole("MANAGER", "ADMIN")

                // all GETs are public
                .anyRequest().permitAll());

        return http.build();
    }
}