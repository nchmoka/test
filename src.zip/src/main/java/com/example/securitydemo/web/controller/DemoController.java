package com.example.securitydemo.web.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoController {

    @GetMapping("/public")
    public String publicAccess() {
        return "Public data";
    }

    @GetMapping("/manage/panel")
    public String managerAccess() {
        return "Manager data";
    }

    @GetMapping("/admin/secure")
    public String adminAccess() {
        return "Admin data";
    }
}
