package com.example.securitydemo.application.service;

import com.example.securitydemo.security.dto.AuthenticatedUser;

public interface ValidateUserUseCase {
    AuthenticatedUser validate(String username);
}
