package com.example.securitydemo.security.token;

import lombok.Getter;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;

@Getter
public class UsernameAuthenticationToken extends AbstractAuthenticationToken {
    private final String username;

    public UsernameAuthenticationToken(String username) {
        super(null);
        this.username = username;
        setAuthenticated(false);
    }

    public UsernameAuthenticationToken(String username, Collection<? extends GrantedAuthority> authorities) {
        super(authorities);
        this.username = username;
        setAuthenticated(true);
    }

    @Override public Object getCredentials() { return null; }

    @Override public Object getPrincipal() { return username; }
}
