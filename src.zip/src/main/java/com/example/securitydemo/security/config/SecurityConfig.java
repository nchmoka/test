package com.example.securitydemo.security.config;

import com.example.securitydemo.security.filter.UsernameAuthFilter;
import com.example.securitydemo.security.provider.UsernameAuthenticationProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@RequiredArgsConstructor
public class SecurityConfig {

    private final UsernameAuthenticationProvider usernameAuthenticationProvider;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        var authManager = new ProviderManager(usernameAuthenticationProvider);

        http
            .cors(cors -> cors
                .configurationSource(request -> {
                    var config = new org.springframework.web.cors.CorsConfiguration();
                    config.setAllowedOrigins(java.util.List.of("*"));
                    config.setAllowedMethods(java.util.List.of("*"));
                    config.setAllowedHeaders(java.util.List.of("*"));
                    return config;
                })
            )
            .csrf().disable()
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/admin/**").hasRole("ADMIN")
                .requestMatchers("/manage/**").hasAnyRole("MANAGER", "ADMIN")
                .anyRequest().permitAll()
            )
            .formLogin().disable()
            .httpBasic().disable()
            .addFilterBefore(new UsernameAuthFilter(authManager), UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}