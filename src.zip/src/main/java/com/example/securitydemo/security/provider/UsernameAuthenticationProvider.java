package com.example.securitydemo.security.provider;

import com.example.securitydemo.security.dto.AuthenticatedUser;
import com.example.securitydemo.security.token.UsernameAuthenticationToken;
import com.example.securitydemo.application.service.ValidateUserUseCase;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class UsernameAuthenticationProvider implements AuthenticationProvider {

    private final ValidateUserUseCase validateUserUseCase;

    @Override
    public Authentication authenticate(Authentication authentication) {
        String username = (String) authentication.getPrincipal();
        AuthenticatedUser user = validateUserUseCase.validate(username);

        if (user == null) {
            throw new BadCredentialsException("Invalid user");
        }

        return new UsernameAuthenticationToken(
            username,
            List.of(new SimpleGrantedAuthority("ROLE_" + user.getRole().toUpperCase()))
        );
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return UsernameAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
